const mongoose = require('mongoose');

const mediaSchema = new mongoose.Schema(
  {
    url: { type: String, required: true },
    publicId: { type: String, required: true },
    name: { type: String, required: true },
    type: { type: String, enum: ['image', 'svg'], default: 'image' },
    folder: { type: String, default: 'general' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Media', mediaSchema);
