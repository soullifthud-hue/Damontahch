const express = require('express');
const router = express.Router();
const {
  customerRegister,
  customerLogin,
  customerLogout,
  getCustomerProfile,
} = require('../controllers/authController');
const { protectCustomer } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/rateLimiter');

router.post('/register', customerRegister);
router.post('/login', loginLimiter, customerLogin);
router.post('/logout', customerLogout);
router.get('/me', protectCustomer, getCustomerProfile);

module.exports = router;
