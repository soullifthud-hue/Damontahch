const Cart = require('../models/Cart');
const Product = require('../models/Product');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');

// Resolves which cart to use: customer's cart if logged in, else guest cart by sessionId
const resolveCartQuery = (req) => {
  if (req.customer) return { customer: req.customer._id };
  const sessionId = req.headers['x-session-id'];
  if (!sessionId) throw new AppError('A session ID header (x-session-id) is required for guest carts.', 400);
  return { sessionId };
};

const getOrCreateCart = async (req) => {
  const query = resolveCartQuery(req);
  let cart = await Cart.findOne(query);
  if (!cart) cart = await Cart.create(query);
  return cart;
};

const computeSummary = async (cart) => {
  const items = await Promise.all(
    cart.items.map(async (item) => {
      const product = await Product.findById(item.product);
      if (!product) return null;
      const price = product.discountPrice && product.discountPrice < product.price ? product.discountPrice : product.price;
      return {
        _id: item._id,
        product: { _id: product._id, name: product.name, slug: product.slug, images: product.images, price: product.price },
        size: item.size,
        color: item.color,
        quantity: item.quantity,
        lineTotal: price * item.quantity,
      };
    })
  );
  const validItems = items.filter(Boolean);
  const subtotal = validItems.reduce((sum, i) => sum + i.lineTotal, 0);
  return { items: validItems, subtotal };
};

// @route GET /api/cart
exports.getCart = asyncHandler(async (req, res) => {
  const cart = await getOrCreateCart(req);
  const summary = await computeSummary(cart);
  res.status(200).json({ success: true, ...summary });
});

// @route POST /api/cart/items
exports.addItem = asyncHandler(async (req, res, next) => {
  const { productId, size, color, quantity = 1 } = req.body;
  const product = await Product.findById(productId);
  if (!product) return next(new AppError('Product not found.', 404));

  const cart = await getOrCreateCart(req);
  const existing = cart.items.find((i) => i.product.toString() === productId && i.size === size && i.color === color);
  if (existing) {
    existing.quantity += Number(quantity);
  } else {
    cart.items.push({ product: productId, size, color, quantity: Number(quantity) });
  }
  await cart.save();
  const summary = await computeSummary(cart);
  res.status(200).json({ success: true, message: 'Added to cart.', ...summary });
});

// @route PUT /api/cart/items/:itemId
exports.updateItemQuantity = asyncHandler(async (req, res, next) => {
  const { quantity } = req.body;
  const cart = await getOrCreateCart(req);
  const item = cart.items.id(req.params.itemId);
  if (!item) return next(new AppError('Cart item not found.', 404));

  if (Number(quantity) <= 0) {
    item.deleteOne();
  } else {
    item.quantity = Number(quantity);
  }
  await cart.save();
  const summary = await computeSummary(cart);
  res.status(200).json({ success: true, ...summary });
});

// @route DELETE /api/cart/items/:itemId
exports.removeItem = asyncHandler(async (req, res, next) => {
  const cart = await getOrCreateCart(req);
  const item = cart.items.id(req.params.itemId);
  if (!item) return next(new AppError('Cart item not found.', 404));
  item.deleteOne();
  await cart.save();
  const summary = await computeSummary(cart);
  res.status(200).json({ success: true, message: 'Removed from cart.', ...summary });
});
