const express = require('express');
const router = express.Router();
const {
  getProducts,
  getSearchSuggestions,
  getProductBySlug,
  getRelatedProducts,
} = require('../controllers/productController');
const { getProductReviews, createReview } = require('../controllers/reviewController');
const { attachCustomerIfPresent } = require('../middleware/auth');
const { uploadReviewPhotos } = require('../middleware/upload');

router.get('/', getProducts);
router.get('/search-suggestions', getSearchSuggestions);
router.get('/:slug', getProductBySlug);
router.get('/:id/related', getRelatedProducts);

router.get('/:productId/reviews', getProductReviews);
router.post('/:productId/reviews', attachCustomerIfPresent, uploadReviewPhotos, createReview);

module.exports = router;
