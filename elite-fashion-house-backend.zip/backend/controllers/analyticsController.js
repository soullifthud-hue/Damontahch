const Product = require('../models/Product');
const Order = require('../models/Order');
const Customer = require('../models/Customer');
const { asyncHandler } = require('../middleware/errorHandler');

// @route GET /api/admin/analytics
exports.getDashboardAnalytics = asyncHandler(async (req, res) => {
  const [
    totalProducts,
    featuredProducts,
    ordersReceived,
    popularProducts,
    topCategoriesAgg,
    wishlistAgg,
    salesAgg,
  ] = await Promise.all([
    Product.countDocuments(),
    Product.countDocuments({ 'flags.featured': true }),
    Order.countDocuments(),
    Product.find().sort({ viewCount: -1 }).limit(6).select('name slug viewCount images'),
    Product.aggregate([
      { $group: { _id: '$category', productCount: { $sum: 1 } } },
      { $sort: { productCount: -1 } },
      { $limit: 5 },
      { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'category' } },
      { $unwind: '$category' },
      { $project: { name: '$category.name', productCount: 1 } },
    ]),
    Customer.aggregate([{ $project: { wishlistSize: { $size: '$wishlist' } } }, { $group: { _id: null, total: { $sum: '$wishlistSize' } } }]),
    Order.aggregate([{ $group: { _id: null, totalRevenue: { $sum: '$total' }, totalOrders: { $sum: 1 } } }]),
  ]);

  // "Visitors" isn't tracked without a payment/analytics gateway yet — reported
  // as null so the dashboard can render a clear "not yet available" state
  // instead of a fabricated number.
  res.status(200).json({
    success: true,
    analytics: {
      totalProducts,
      featuredProducts,
      ordersReceived,
      visitors: null,
      popularProducts,
      wishlistCount: wishlistAgg[0]?.total || 0,
      topCategories: topCategoriesAgg,
      salesOverview: {
        totalRevenue: salesAgg[0]?.totalRevenue || 0,
        totalOrders: salesAgg[0]?.totalOrders || 0,
        note: 'Placeholder overview — will include payment-gateway data once integrated.',
      },
    },
  });
});
