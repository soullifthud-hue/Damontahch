const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: ['new_order', 'low_stock', 'out_of_stock', 'new_review', 'contact_submission'],
      required: true,
    },
    message: { type: String, required: true },
    link: String, // e.g. /admin/orders/:id for the dashboard to route to
    isRead: { type: Boolean, default: false },
  },
  { timestamps: true }
);

notificationSchema.index({ isRead: 1, createdAt: -1 });

module.exports = mongoose.model('Notification', notificationSchema);
