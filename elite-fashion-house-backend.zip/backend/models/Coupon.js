const mongoose = require('mongoose');

const couponSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true, uppercase: true, trim: true },
    type: { type: String, enum: ['percent', 'fixed', 'bogo', 'free_delivery'], required: true },
    value: { type: Number, default: 0 }, // percent or fixed amount; ignored for bogo/free_delivery
    minOrderAmount: { type: Number, default: 0 },
    maxDiscountAmount: { type: Number },
    isFlashSale: { type: Boolean, default: false },
    usageLimit: { type: Number }, // total redemptions allowed, blank = unlimited
    usedCount: { type: Number, default: 0 },
    perCustomerLimit: { type: Number, default: 1 },
    startsAt: { type: Date, default: Date.now },
    expiresAt: { type: Date, required: true },
    isActive: { type: Boolean, default: true },
    description: String,
  },
  { timestamps: true }
);

couponSchema.methods.isValidNow = function () {
  const now = new Date();
  return (
    this.isActive &&
    now >= this.startsAt &&
    now <= this.expiresAt &&
    (this.usageLimit == null || this.usedCount < this.usageLimit)
  );
};

module.exports = mongoose.model('Coupon', couponSchema);
