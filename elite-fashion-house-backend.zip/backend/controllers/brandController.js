const Brand = require('../models/Brand');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');

exports.getBrands = asyncHandler(async (req, res) => {
  const brands = await Brand.find({ isActive: true }).sort({ name: 1 });
  res.status(200).json({ success: true, brands });
});

exports.getAdminBrands = asyncHandler(async (req, res) => {
  const brands = await Brand.find().sort({ name: 1 });
  res.status(200).json({ success: true, brands });
});

exports.createBrand = asyncHandler(async (req, res) => {
  const body = { ...req.body };
  if (req.file) body.logo = { url: req.file.path, publicId: req.file.filename };
  const brand = await Brand.create(body);
  res.status(201).json({ success: true, brand });
});

exports.updateBrand = asyncHandler(async (req, res, next) => {
  const body = { ...req.body };
  if (req.file) body.logo = { url: req.file.path, publicId: req.file.filename };
  const brand = await Brand.findByIdAndUpdate(req.params.id, body, { new: true, runValidators: true });
  if (!brand) return next(new AppError('Brand not found.', 404));
  res.status(200).json({ success: true, brand });
});

exports.deleteBrand = asyncHandler(async (req, res, next) => {
  const brand = await Brand.findByIdAndDelete(req.params.id);
  if (!brand) return next(new AppError('Brand not found.', 404));
  res.status(200).json({ success: true, message: 'Brand deleted.' });
});
