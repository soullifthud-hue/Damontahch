const express = require('express');
const router = express.Router();
const { updateSettings } = require('../controllers/settingsController');
const { uploadSettingsAssets } = require('../middleware/upload');

router.put('/', uploadSettingsAssets, updateSettings);

module.exports = router;
