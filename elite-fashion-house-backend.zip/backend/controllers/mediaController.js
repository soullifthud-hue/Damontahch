const Media = require('../models/Media');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');
const { cloudinary } = require('../config/cloudinary');

// @route GET /api/admin/media
exports.getMedia = asyncHandler(async (req, res) => {
  const { folder } = req.query;
  const filter = folder ? { folder } : {};
  const media = await Media.find(filter).sort({ createdAt: -1 });
  res.status(200).json({ success: true, count: media.length, media });
});

// @route POST /api/admin/media
exports.uploadMediaFile = asyncHandler(async (req, res, next) => {
  if (!req.file) return next(new AppError('No file uploaded.', 400));
  const media = await Media.create({
    url: req.file.path,
    publicId: req.file.filename,
    name: req.body.name || req.file.originalname,
    folder: req.body.folder || 'general',
  });
  res.status(201).json({ success: true, media });
});

// @route PUT /api/admin/media/:id
exports.renameMedia = asyncHandler(async (req, res, next) => {
  const media = await Media.findByIdAndUpdate(req.params.id, { name: req.body.name, folder: req.body.folder }, { new: true });
  if (!media) return next(new AppError('Media not found.', 404));
  res.status(200).json({ success: true, media });
});

// @route DELETE /api/admin/media/:id
exports.deleteMedia = asyncHandler(async (req, res, next) => {
  const media = await Media.findById(req.params.id);
  if (!media) return next(new AppError('Media not found.', 404));
  await cloudinary.uploader.destroy(media.publicId).catch(() => null);
  await media.deleteOne();
  res.status(200).json({ success: true, message: 'Media deleted.' });
});
