const Admin = require('../models/Admin');
const Customer = require('../models/Customer');
const AppError = require('../utils/AppError');
const { sendTokenResponse } = require('../utils/generateToken');
const { asyncHandler } = require('../middleware/errorHandler');

// @route POST /api/admin/auth/login  (hidden route, never linked publicly)
exports.adminLogin = asyncHandler(async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) return next(new AppError('Email and password are required.', 400));

  const admin = await Admin.findOne({ email: email.toLowerCase() }).select('+password');
  if (!admin || !(await admin.comparePassword(password))) {
    return next(new AppError('Invalid credentials.', 401));
  }

  admin.lastLoginAt = new Date();
  await admin.save({ validateBeforeSave: false });

  sendTokenResponse(res, 200, admin._id, 'admin', {
    admin: { id: admin._id, name: admin.name, email: admin.email },
  });
});

// @route POST /api/admin/auth/logout
exports.adminLogout = asyncHandler(async (req, res) => {
  res.clearCookie('token');
  res.status(200).json({ success: true, message: 'Logged out.' });
});

// @route GET /api/admin/auth/me
exports.getAdminProfile = asyncHandler(async (req, res) => {
  res.status(200).json({ success: true, admin: { id: req.admin._id, name: req.admin.name, email: req.admin.email } });
});

// ---------- Customer auth (optional accounts, never admin privileges) ----------

// @route POST /api/customers/register
exports.customerRegister = asyncHandler(async (req, res, next) => {
  const { name, email, phone, password } = req.body;
  if (!name || !email || !password) return next(new AppError('Name, email and password are required.', 400));

  const exists = await Customer.findOne({ email: email.toLowerCase() });
  if (exists) return next(new AppError('An account with this email already exists.', 409));

  const customer = await Customer.create({ name, email, phone, password });
  sendTokenResponse(res, 201, customer._id, 'customer', {
    customer: { id: customer._id, name: customer.name, email: customer.email },
  });
});

// @route POST /api/customers/login
exports.customerLogin = asyncHandler(async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) return next(new AppError('Email and password are required.', 400));

  const customer = await Customer.findOne({ email: email.toLowerCase() }).select('+password');
  if (!customer || !(await customer.comparePassword(password))) {
    return next(new AppError('Invalid credentials.', 401));
  }
  if (!customer.isActive) return next(new AppError('This account has been deactivated.', 403));

  sendTokenResponse(res, 200, customer._id, 'customer', {
    customer: { id: customer._id, name: customer.name, email: customer.email },
  });
});

// @route POST /api/customers/logout
exports.customerLogout = asyncHandler(async (req, res) => {
  res.clearCookie('token');
  res.status(200).json({ success: true, message: 'Logged out.' });
});

// @route GET /api/customers/me
exports.getCustomerProfile = asyncHandler(async (req, res) => {
  res.status(200).json({ success: true, customer: req.customer });
});
