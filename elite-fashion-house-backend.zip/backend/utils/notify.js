const Notification = require('../models/Notification');

async function notify(type, message, link) {
  try {
    await Notification.create({ type, message, link });
  } catch (err) {
    // Notification failures should never break the primary request flow
    console.error('Notification creation failed:', err.message);
  }
}

module.exports = notify;
