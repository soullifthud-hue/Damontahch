const express = require('express');
const router = express.Router();
const {
  getAdminProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  deleteProductImage,
} = require('../controllers/productController');
const { uploadProductImages } = require('../middleware/upload');

router.get('/', getAdminProducts);
router.post('/', uploadProductImages, createProduct);
router.put('/:id', uploadProductImages, updateProduct);
router.delete('/:id', deleteProduct);
router.delete('/:id/images/:publicId', deleteProductImage);

module.exports = router;
