const cloudinary = require('cloudinary').v2;
const { CloudinaryStorage } = require('multer-storage-cloudinary');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Storage for product / gallery images
const productStorage = new CloudinaryStorage({
  cloudinary,
  params: {
    folder: 'elite-fashion-house/products',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp'],
    transformation: [{ width: 1600, crop: 'limit', quality: 'auto' }],
  },
});

// Storage for general media library (banners, logos, etc.)
const mediaStorage = new CloudinaryStorage({
  cloudinary,
  params: {
    folder: 'elite-fashion-house/media',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp', 'svg'],
    transformation: [{ width: 2400, crop: 'limit', quality: 'auto' }],
  },
});

// Storage for review photos
const reviewStorage = new CloudinaryStorage({
  cloudinary,
  params: {
    folder: 'elite-fashion-house/reviews',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp'],
    transformation: [{ width: 1000, crop: 'limit', quality: 'auto' }],
  },
});

module.exports = { cloudinary, productStorage, mediaStorage, reviewStorage };
