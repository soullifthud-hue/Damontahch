const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema(
  {
    singleton: { type: String, default: 'site-settings', unique: true },

    businessName: { type: String, default: 'Elite Fashion House' },
    tagline: { type: String, default: 'Style That Defines You' },
    about: String,
    mission: String,
    vision: String,

    logo: { url: String, publicId: String },
    favicon: { url: String, publicId: String },

    contact: {
      phone: String,
      whatsapp: String,
      email: String,
      address: String,
    },

    businessHours: [{ days: String, hours: String }],

    socials: {
      facebook: String,
      instagram: String,
      tiktok: String,
      youtube: String,
    },

    theme: {
      primaryColor: { type: String, default: '#000000' },
      secondaryColor: { type: String, default: '#C9A227' },
      accentColor: { type: String, default: '#FFFFFF' },
      darkMode: { type: Boolean, default: true },
    },

    delivery: {
      insideDhakaCharge: { type: Number, default: 70 },
      outsideDhakaCharge: { type: Number, default: 120 },
      exchangeWindowDays: { type: Number, default: 7 },
    },

    seo: {
      metaTitle: String,
      metaDescription: String,
    },

    defaultLanguage: { type: String, default: 'en' },
    defaultCurrency: { type: String, default: 'BDT' },

    footerText: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Settings', settingsSchema);
