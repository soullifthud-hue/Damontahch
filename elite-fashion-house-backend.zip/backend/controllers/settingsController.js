const Settings = require('../models/Settings');
const { asyncHandler } = require('../middleware/errorHandler');

const getOrCreateSettings = async () => {
  let settings = await Settings.findOne();
  if (!settings) settings = await Settings.create({});
  return settings;
};

// @route GET /api/settings  (public — powers header/footer/contact everywhere)
exports.getSettings = asyncHandler(async (req, res) => {
  const settings = await getOrCreateSettings();
  res.status(200).json({ success: true, settings });
});

// @route PUT /api/admin/settings
exports.updateSettings = asyncHandler(async (req, res) => {
  const settings = await getOrCreateSettings();
  const body = { ...req.body };
  if (typeof body.contact === 'string') body.contact = JSON.parse(body.contact);
  if (typeof body.socials === 'string') body.socials = JSON.parse(body.socials);
  if (typeof body.theme === 'string') body.theme = JSON.parse(body.theme);
  if (typeof body.delivery === 'string') body.delivery = JSON.parse(body.delivery);
  if (typeof body.seo === 'string') body.seo = JSON.parse(body.seo);
  if (typeof body.businessHours === 'string') body.businessHours = JSON.parse(body.businessHours);

  if (req.files?.logo?.[0]) body.logo = { url: req.files.logo[0].path, publicId: req.files.logo[0].filename };
  if (req.files?.favicon?.[0]) body.favicon = { url: req.files.favicon[0].path, publicId: req.files.favicon[0].filename };

  Object.assign(settings, body);
  await settings.save();

  res.status(200).json({ success: true, settings });
});
