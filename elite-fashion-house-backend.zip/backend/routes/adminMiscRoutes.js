const express = require('express');
const router = express.Router();
const { getSubscribers, exportSubscribers } = require('../controllers/subscriberController');
const { getContactMessages, updateContactStatus } = require('../controllers/contactController');
const { getNotifications, markAsRead, markAllAsRead } = require('../controllers/notificationController');
const { getDashboardAnalytics } = require('../controllers/analyticsController');

router.get('/newsletter/subscribers', getSubscribers);
router.get('/newsletter/subscribers/export', exportSubscribers);

router.get('/contact', getContactMessages);
router.put('/contact/:id/status', updateContactStatus);

router.get('/notifications', getNotifications);
router.put('/notifications/:id/read', markAsRead);
router.put('/notifications/read-all', markAllAsRead);

router.get('/analytics', getDashboardAnalytics);

module.exports = router;
