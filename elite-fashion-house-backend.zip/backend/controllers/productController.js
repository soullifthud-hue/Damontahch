const Product = require('../models/Product');
const AppError = require('../utils/AppError');
const notify = require('../utils/notify');
const { asyncHandler } = require('../middleware/errorHandler');
const { cloudinary } = require('../config/cloudinary');

const LOW_STOCK_THRESHOLD = 5;

// @route GET /api/products
// Supports: search (q), category, brand, gender, minPrice, maxPrice, color, size,
// availability, flags (featured/bestSeller/newArrival/trending), sort, page, limit
exports.getProducts = asyncHandler(async (req, res) => {
  const {
    q, category, brand, gender, minPrice, maxPrice, color, size,
    availability, featured, bestSeller, newArrival, trending,
    sort, page = 1, limit = 24,
  } = req.query;

  const filter = { status: 'published' };
  if (q) filter.$text = { $search: q };
  if (category) filter.category = category;
  if (brand) filter.brand = brand;
  if (gender) filter.gender = gender;
  if (color) filter.colors = color;
  if (size) filter.sizes = size;
  if (availability === 'in_stock') filter.stockQuantity = { $gt: 0 };
  if (availability === 'out_of_stock') filter.stockQuantity = { $lte: 0 };
  if (featured === 'true') filter['flags.featured'] = true;
  if (bestSeller === 'true') filter['flags.bestSeller'] = true;
  if (newArrival === 'true') filter['flags.newArrival'] = true;
  if (trending === 'true') filter['flags.trending'] = true;
  if (minPrice || maxPrice) {
    filter.price = {};
    if (minPrice) filter.price.$gte = Number(minPrice);
    if (maxPrice) filter.price.$lte = Number(maxPrice);
  }

  const sortMap = {
    newest: { createdAt: -1 },
    oldest: { createdAt: 1 },
    price_low: { price: 1 },
    price_high: { price: -1 },
    best_selling: { soldCount: -1 },
    top_rated: { ratingAverage: -1 },
  };
  const sortBy = sortMap[sort] || sortMap.newest;

  const skip = (Number(page) - 1) * Number(limit);
  const [products, total] = await Promise.all([
    Product.find(filter).sort(sortBy).skip(skip).limit(Number(limit)).populate('category brand', 'name slug'),
    Product.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    count: products.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    products,
  });
});

// @route GET /api/products/search-suggestions?q=
exports.getSearchSuggestions = asyncHandler(async (req, res) => {
  const { q } = req.query;
  if (!q || q.trim().length < 2) return res.status(200).json({ success: true, suggestions: [] });

  const products = await Product.find(
    { status: 'published', $text: { $search: q } },
    { name: 1, slug: 1, images: 1, price: 1 }
  ).limit(8);

  res.status(200).json({ success: true, suggestions: products });
});

// @route GET /api/products/:slug
exports.getProductBySlug = asyncHandler(async (req, res, next) => {
  const product = await Product.findOneAndUpdate(
    { slug: req.params.slug, status: 'published' },
    { $inc: { viewCount: 1 } },
    { new: true }
  ).populate('category brand', 'name slug');

  if (!product) return next(new AppError('Product not found.', 404));
  res.status(200).json({ success: true, product });
});

// @route GET /api/products/:id/related
exports.getRelatedProducts = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError('Product not found.', 404));

  const related = await Product.find({
    _id: { $ne: product._id },
    category: product.category,
    status: 'published',
  }).limit(8);

  res.status(200).json({ success: true, products: related });
});

// ---------- Admin ----------

// @route POST /api/admin/products
exports.createProduct = asyncHandler(async (req, res, next) => {
  const body = { ...req.body };
  if (typeof body.flags === 'string') body.flags = JSON.parse(body.flags);
  if (typeof body.sizes === 'string') body.sizes = JSON.parse(body.sizes);
  if (typeof body.colors === 'string') body.colors = JSON.parse(body.colors);
  if (typeof body.tags === 'string') body.tags = JSON.parse(body.tags);
  if (typeof body.variants === 'string') body.variants = JSON.parse(body.variants);

  if (req.files && req.files.length > 0) {
    body.images = req.files.map((f, idx) => ({
      url: f.path,
      publicId: f.filename,
      angle: idx === 0 ? 'main' : 'gallery',
    }));
  } else {
    return next(new AppError('At least one product image is required.', 400));
  }

  const product = await Product.create(body);
  res.status(201).json({ success: true, product });
});

// @route PUT /api/admin/products/:id
exports.updateProduct = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError('Product not found.', 404));

  const body = { ...req.body };
  if (typeof body.flags === 'string') body.flags = JSON.parse(body.flags);
  if (typeof body.sizes === 'string') body.sizes = JSON.parse(body.sizes);
  if (typeof body.colors === 'string') body.colors = JSON.parse(body.colors);
  if (typeof body.tags === 'string') body.tags = JSON.parse(body.tags);
  if (typeof body.variants === 'string') body.variants = JSON.parse(body.variants);

  if (req.files && req.files.length > 0) {
    const newImages = req.files.map((f) => ({ url: f.path, publicId: f.filename, angle: 'gallery' }));
    body.images = [...product.images, ...newImages];
  }

  Object.assign(product, body);
  await product.save();

  const wasInStock = product.stockQuantity > 0;
  if (product.stockQuantity <= 0) {
    await notify('out_of_stock', `${product.name} is now out of stock.`, `/admin/products/${product._id}`);
  } else if (product.stockQuantity <= LOW_STOCK_THRESHOLD) {
    await notify('low_stock', `${product.name} is low on stock (${product.stockQuantity} left).`, `/admin/products/${product._id}`);
  }

  res.status(200).json({ success: true, product });
});

// @route DELETE /api/admin/products/:id
exports.deleteProduct = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError('Product not found.', 404));

  await Promise.all(
    product.images.map((img) => cloudinary.uploader.destroy(img.publicId).catch(() => null))
  );
  await product.deleteOne();

  res.status(200).json({ success: true, message: 'Product deleted.' });
});

// @route DELETE /api/admin/products/:id/images/:publicId
exports.deleteProductImage = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError('Product not found.', 404));

  product.images = product.images.filter((img) => img.publicId !== req.params.publicId);
  await product.save();
  await cloudinary.uploader.destroy(req.params.publicId).catch(() => null);

  res.status(200).json({ success: true, product });
});

// @route GET /api/admin/products  (all statuses, for dashboard table)
exports.getAdminProducts = asyncHandler(async (req, res) => {
  const { page = 1, limit = 30, status, q } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (q) filter.$text = { $search: q };

  const skip = (Number(page) - 1) * Number(limit);
  const [products, total] = await Promise.all([
    Product.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Product.countDocuments(filter),
  ]);

  res.status(200).json({ success: true, count: products.length, total, products });
});
