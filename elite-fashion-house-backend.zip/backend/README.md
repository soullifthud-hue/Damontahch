# Elite Fashion House — Backend API

Node.js / Express / MongoDB backend for the Elite Fashion House e-commerce platform.
No payment gateway — checkout happens via a prefilled WhatsApp order link, with Cash on Delivery.

## 1. Install

```bash
cd backend
npm install
```

## 2. Configure environment

```bash
cp .env.example .env
```

Fill in `.env`:

- `MONGO_URI` — from MongoDB Atlas (create a free cluster, add a database user, allow your IP / 0.0.0.0/0)
- `JWT_SECRET` — any long random string (e.g. `openssl rand -hex 32`)
- `CLOUDINARY_*` — from your Cloudinary dashboard (free tier is fine)
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — used once by the seed script below, then you can remove them
- `CLIENT_URL` — the deployed frontend URL (for CORS)

## 3. Create the one admin account

There is no public registration route — the single admin account is created once via:

```bash
npm run seed:admin
```

This reads `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` from `.env` and refuses to run if an admin already exists.

## 4. Run locally

```bash
npm run dev      # nodemon, auto-restart
# or
npm start        # plain node
```

API will be live at `http://localhost:5000/api`. Health check: `GET /api/health`.

## 5. MongoDB Atlas setup (summary)

1. Create a free cluster at cloud.mongodb.com
2. Database Access → add a user with a strong password
3. Network Access → add your IP (or `0.0.0.0/0` for early development)
4. Connect → "Drivers" → copy the connection string into `MONGO_URI`

## 6. Deploy

**Backend → Render or Railway**
- New Web Service → connect this repo/folder
- Build command: `npm install`
- Start command: `npm start`
- Add all variables from `.env` in the service's Environment settings
- After first deploy, run the seed script once via the platform's shell/console tab

**Database → MongoDB Atlas** (already configured above)

**Image storage → Cloudinary** (already configured above)

**Frontend → Vercel**
- Point the frontend's API base URL at your deployed backend URL
- Set `CLIENT_URL` in the backend's env to the deployed Vercel URL so CORS allows it

## API overview

- `/api/products` — public browse/search/filter, product detail, reviews
- `/api/categories`, `/api/brands` — public catalog listings
- `/api/homepage` — everything the homepage needs in one call
- `/api/cart`, `/api/orders` — guest or logged-in cart, WhatsApp checkout
- `/api/customers/*` — optional customer accounts, wishlist, order history
- `/api/coupons/validate`, `/api/gift-cards/check` — promotions at checkout
- `/api/newsletter/*`, `/api/contact` — support/marketing
- `/api/admin/*` — everything above plus full CRUD, all behind the hidden
  `/api/admin/auth/login` route and JWT auth. Never linked from the public site.

## Security notes

- Passwords hashed with bcrypt, JWT in httpOnly cookie + bearer token
- `express-mongo-sanitize` + `xss-clean` on all input, `helmet` headers, CORS locked to `CLIENT_URL`
- Rate limiting on all `/api` routes, tighter limit on login endpoints
- Upload validation: type (jpg/png/webp/svg only) + 8MB size cap, randomized Cloudinary filenames
- No stack traces are ever sent to the client (see `middleware/errorHandler.js`)
