const Category = require('../models/Category');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');

exports.getCategories = asyncHandler(async (req, res) => {
  const filter = { isActive: true };
  if (req.query.gender) filter.gender = req.query.gender;
  const categories = await Category.find(filter).sort({ sortOrder: 1, name: 1 });
  res.status(200).json({ success: true, categories });
});

exports.getAdminCategories = asyncHandler(async (req, res) => {
  const categories = await Category.find().sort({ sortOrder: 1, name: 1 });
  res.status(200).json({ success: true, categories });
});

exports.createCategory = asyncHandler(async (req, res) => {
  const body = { ...req.body };
  if (req.file) body.image = { url: req.file.path, publicId: req.file.filename };
  const category = await Category.create(body);
  res.status(201).json({ success: true, category });
});

exports.updateCategory = asyncHandler(async (req, res, next) => {
  const body = { ...req.body };
  if (req.file) body.image = { url: req.file.path, publicId: req.file.filename };
  const category = await Category.findByIdAndUpdate(req.params.id, body, { new: true, runValidators: true });
  if (!category) return next(new AppError('Category not found.', 404));
  res.status(200).json({ success: true, category });
});

exports.deleteCategory = asyncHandler(async (req, res, next) => {
  const category = await Category.findByIdAndDelete(req.params.id);
  if (!category) return next(new AppError('Category not found.', 404));
  res.status(200).json({ success: true, message: 'Category deleted.' });
});
