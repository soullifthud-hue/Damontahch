// One-time bootstrap script: creates the single admin account from .env values.
// Run with: npm run seed:admin
// Refuses to run if an admin already exists.
require('dotenv').config();
const mongoose = require('mongoose');
const Admin = require('../models/Admin');

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    const existing = await Admin.countDocuments();
    if (existing > 0) {
      console.log('An admin account already exists. Aborting — only one admin is allowed.');
      process.exit(0);
    }

    if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) {
      console.error('ADMIN_EMAIL and ADMIN_PASSWORD must be set in .env before seeding.');
      process.exit(1);
    }

    const admin = await Admin.create({
      name: process.env.ADMIN_NAME || 'Website Owner',
      email: process.env.ADMIN_EMAIL,
      password: process.env.ADMIN_PASSWORD,
    });

    console.log(`Admin account created for ${admin.email}. You can now log in at the hidden admin route.`);
    process.exit(0);
  } catch (err) {
    console.error('Seeding failed:', err.message);
    process.exit(1);
  }
})();
