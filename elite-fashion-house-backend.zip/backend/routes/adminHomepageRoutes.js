const express = require('express');
const router = express.Router();
const { getAdminHomepageSections, upsertHomepageSection } = require('../controllers/homepageController');
const { uploadSingleMedia } = require('../middleware/upload');

router.get('/', getAdminHomepageSections);
router.put('/:key', uploadSingleMedia, upsertHomepageSection);

module.exports = router;
