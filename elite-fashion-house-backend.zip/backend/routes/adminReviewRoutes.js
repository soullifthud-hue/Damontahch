const express = require('express');
const router = express.Router();
const { getAdminReviews, moderateReview, deleteReview } = require('../controllers/reviewController');

router.get('/', getAdminReviews);
router.put('/:id/status', moderateReview);
router.delete('/:id', deleteReview);

module.exports = router;
