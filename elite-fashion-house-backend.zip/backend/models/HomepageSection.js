const mongoose = require('mongoose');

// Editable content blocks the admin controls: hero, promo banner, brand story, etc.
// Collection blocks (Featured/New Arrivals/etc.) are query-driven from Product.flags
// and don't need rows here — only free-form/manual content blocks do.
const homepageSectionSchema = new mongoose.Schema(
  {
    key: {
      type: String,
      required: true,
      unique: true,
      enum: ['hero', 'promoBanner', 'brandStory', 'seasonalBanner'],
    },
    title: String,
    subtitle: String,
    ctaText: String,
    ctaLink: String,
    image: { url: String, publicId: String },
    video: { url: String, publicId: String },
    isActive: { type: Boolean, default: true },
    sortOrder: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('HomepageSection', homepageSectionSchema);
