const express = require('express');
const router = express.Router();
const { protectAdmin } = require('../middleware/auth');

// Auth routes are NOT protected (login must be reachable), everything else is.
router.use('/auth', require('./adminAuthRoutes'));

router.use(protectAdmin);

router.use('/products', require('./adminProductRoutes'));
router.use('/catalog', require('./adminCatalogRoutes')); // categories + brands
router.use('/orders', require('./adminOrderRoutes'));
router.use('/reviews', require('./adminReviewRoutes'));
router.use('/promotions', require('./adminPromotionRoutes')); // coupons + gift cards
router.use('/homepage', require('./adminHomepageRoutes'));
router.use('/settings', require('./adminSettingsRoutes'));
router.use('/media', require('./adminMediaRoutes'));
router.use('/', require('./adminMiscRoutes')); // newsletter, contact, notifications, analytics

module.exports = router;
