const mongoose = require('mongoose');
const crypto = require('crypto');

const giftCardSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true, uppercase: true },
    amount: { type: Number, required: true, min: 0 },
    balance: { type: Number, required: true, min: 0 },
    issuedTo: { type: String }, // email or phone, optional
    expiresAt: { type: Date, required: true },
    isActive: { type: Boolean, default: true },
    redemptions: [
      {
        order: { type: mongoose.Schema.Types.ObjectId, ref: 'Order' },
        amountUsed: Number,
        redeemedAt: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

giftCardSchema.pre('validate', function (next) {
  if (!this.code) {
    this.code = `EFH-GC-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  }
  if (this.isNew && this.balance == null) {
    this.balance = this.amount;
  }
  next();
});

module.exports = mongoose.model('GiftCard', giftCardSchema);
