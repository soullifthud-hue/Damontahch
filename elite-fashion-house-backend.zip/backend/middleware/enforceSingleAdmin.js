const Admin = require('../models/Admin');

// There is exactly one admin account, created once via `npm run seed:admin`.
// There is intentionally no public/admin registration endpoint. This guard
// exists as a second line of defense for any internal tooling that might
// try to create an admin document directly.
module.exports = async function enforceSingleAdmin(req, res, next) {
  const existingCount = await Admin.countDocuments();
  if (existingCount >= 1) {
    return res.status(403).json({
      success: false,
      message: 'An admin account already exists. Registration is disabled.',
    });
  }
  next();
};
