const express = require('express');
const router = express.Router();

const { getCategories } = require('../controllers/categoryController');
const { getBrands } = require('../controllers/brandController');
const { getHomepageData } = require('../controllers/homepageController');
const { getCart, addItem, updateItemQuantity, removeItem } = require('../controllers/cartController');
const { createOrder } = require('../controllers/orderController');
const { validateCoupon } = require('../controllers/couponController');
const { checkGiftCard } = require('../controllers/giftCardController');
const { subscribe, unsubscribe } = require('../controllers/subscriberController');
const { submitContactForm } = require('../controllers/contactController');
const { getSettings } = require('../controllers/settingsController');
const { attachCustomerIfPresent } = require('../middleware/auth');

router.get('/categories', getCategories);
router.get('/brands', getBrands);
router.get('/homepage', getHomepageData);
router.get('/settings', getSettings);

router.get('/cart', attachCustomerIfPresent, getCart);
router.post('/cart/items', attachCustomerIfPresent, addItem);
router.put('/cart/items/:itemId', attachCustomerIfPresent, updateItemQuantity);
router.delete('/cart/items/:itemId', attachCustomerIfPresent, removeItem);

router.post('/orders', attachCustomerIfPresent, createOrder);

router.post('/coupons/validate', validateCoupon);
router.post('/gift-cards/check', checkGiftCard);

router.post('/newsletter/subscribe', subscribe);
router.post('/newsletter/unsubscribe', unsubscribe);

router.post('/contact', submitContactForm);

module.exports = router;
