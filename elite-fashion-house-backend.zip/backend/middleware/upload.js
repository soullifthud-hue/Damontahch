const multer = require('multer');
const { productStorage, mediaStorage, reviewStorage } = require('../config/cloudinary');

const ALLOWED_MIME = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
const MAX_FILE_SIZE = 8 * 1024 * 1024; // 8MB

const fileFilter = (req, file, cb) => {
  if (!ALLOWED_MIME.includes(file.mimetype)) {
    return cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'Only JPG, PNG, WEBP or SVG images are allowed.'));
  }
  cb(null, true);
};

const buildUploader = (storage) =>
  multer({
    storage,
    fileFilter,
    limits: { fileSize: MAX_FILE_SIZE },
  });

// Product images: multiple files, multiple angles (main/front/back/side/closeup/gallery)
exports.uploadProductImages = buildUploader(productStorage).array('images', 12);

// General media library uploads (banners, logos, favicons)
exports.uploadMedia = buildUploader(mediaStorage).single('file');

// Review photos: a few per review
exports.uploadReviewPhotos = buildUploader(reviewStorage).array('photos', 4);

// Settings: logo + favicon uploaded together as named fields
exports.uploadSettingsAssets = buildUploader(mediaStorage).fields([
  { name: 'logo', maxCount: 1 },
  { name: 'favicon', maxCount: 1 },
]);

// Single media-library upload (banners, homepage images, etc.)
exports.uploadSingleMedia = buildUploader(mediaStorage).single('image');
