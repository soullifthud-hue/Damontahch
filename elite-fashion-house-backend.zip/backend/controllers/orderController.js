const Order = require('../models/Order');
const Product = require('../models/Product');
const Coupon = require('../models/Coupon');
const Settings = require('../models/Settings');
const AppError = require('../utils/AppError');
const notify = require('../utils/notify');
const { asyncHandler } = require('../middleware/errorHandler');

// @route POST /api/orders
// Creates the order record AND returns a prefilled WhatsApp deep link.
// No payment gateway is involved — this is the sole checkout path today.
exports.createOrder = asyncHandler(async (req, res, next) => {
  const { items, customerName, customerPhone, deliveryAddress, deliveryZone, couponCode, notes } = req.body;

  if (!items || items.length === 0) return next(new AppError('Order must include at least one item.', 400));
  if (!customerName || !customerPhone) return next(new AppError('Customer name and phone are required.', 400));

  const settings = await Settings.findOne();
  const insideCharge = settings?.delivery?.insideDhakaCharge ?? 70;
  const outsideCharge = settings?.delivery?.outsideDhakaCharge ?? 120;
  const deliveryCharge = deliveryZone === 'Outside Dhaka' ? outsideCharge : insideCharge;

  const resolvedItems = [];
  let subtotal = 0;
  for (const item of items) {
    const product = await Product.findById(item.productId);
    if (!product) return next(new AppError(`Product not found: ${item.productId}`, 404));
    const price = product.discountPrice && product.discountPrice < product.price ? product.discountPrice : product.price;
    const lineTotal = price * item.quantity;
    subtotal += lineTotal;
    resolvedItems.push({
      product: product._id,
      name: product.name,
      image: product.images?.[0]?.url,
      price,
      size: item.size,
      color: item.color,
      quantity: item.quantity,
    });
  }

  let discount = 0;
  let appliedCoupon = null;
  if (couponCode) {
    const coupon = await Coupon.findOne({ code: couponCode.toUpperCase() });
    if (coupon && coupon.isValidNow() && subtotal >= coupon.minOrderAmount) {
      if (coupon.type === 'percent') {
        discount = (subtotal * coupon.value) / 100;
        if (coupon.maxDiscountAmount) discount = Math.min(discount, coupon.maxDiscountAmount);
      } else if (coupon.type === 'fixed') {
        discount = coupon.value;
      } else if (coupon.type === 'free_delivery') {
        discount = deliveryCharge;
      }
      coupon.usedCount += 1;
      await coupon.save();
      appliedCoupon = coupon.code;
    }
  }

  const total = Math.max(subtotal + deliveryCharge - discount, 0);

  const order = await Order.create({
    customer: req.customer ? req.customer._id : null,
    customerName,
    customerPhone,
    deliveryAddress,
    deliveryZone: deliveryZone === 'Outside Dhaka' ? 'Outside Dhaka' : 'Inside Dhaka',
    deliveryCharge,
    items: resolvedItems,
    subtotal,
    discount,
    couponCode: appliedCoupon,
    total,
    notes,
  });

  await notify('new_order', `New WhatsApp order ${order.orderNumber} from ${customerName}.`, `/admin/orders/${order._id}`);

  const businessWhatsapp = (settings?.contact?.whatsapp || '').replace(/[^0-9]/g, '');
  const lines = resolvedItems.map(
    (i) => `- ${i.name} (${i.size || '-'}/${i.color || '-'}) x${i.quantity} — ৳${i.price * i.quantity}`
  );
  const messageText = [
    `New Order: ${order.orderNumber}`,
    `Name: ${customerName}`,
    `Phone: ${customerPhone}`,
    deliveryAddress ? `Address: ${deliveryAddress}` : null,
    '',
    'Items:',
    ...lines,
    '',
    `Subtotal: ৳${subtotal}`,
    `Delivery: ৳${deliveryCharge}`,
    discount ? `Discount: -৳${discount}` : null,
    `Total: ৳${total}`,
  ]
    .filter(Boolean)
    .join('\n');

  const whatsappLink = `https://wa.me/${businessWhatsapp}?text=${encodeURIComponent(messageText)}`;

  res.status(201).json({ success: true, order, whatsappLink });
});

// @route GET /api/customers/orders  (order history for logged-in customer)
exports.getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ customer: req.customer._id }).sort({ createdAt: -1 });
  res.status(200).json({ success: true, orders });
});

// ---------- Admin ----------

// @route GET /api/admin/orders
exports.getAdminOrders = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 30 } = req.query;
  const filter = {};
  if (status) filter.status = status;
  const skip = (Number(page) - 1) * Number(limit);
  const [orders, total] = await Promise.all([
    Order.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Order.countDocuments(filter),
  ]);
  res.status(200).json({ success: true, count: orders.length, total, orders });
});

// @route PUT /api/admin/orders/:id/status
exports.updateOrderStatus = asyncHandler(async (req, res, next) => {
  const order = await Order.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true, runValidators: true }
  );
  if (!order) return next(new AppError('Order not found.', 404));
  res.status(200).json({ success: true, order });
});
