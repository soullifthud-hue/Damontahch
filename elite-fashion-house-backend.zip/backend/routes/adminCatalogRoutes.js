const express = require('express');
const router = express.Router();
const {
  getAdminCategories, createCategory, updateCategory, deleteCategory,
} = require('../controllers/categoryController');
const {
  getAdminBrands, createBrand, updateBrand, deleteBrand,
} = require('../controllers/brandController');
const { uploadSingleMedia } = require('../middleware/upload');

router.get('/categories', getAdminCategories);
router.post('/categories', uploadSingleMedia, createCategory);
router.put('/categories/:id', uploadSingleMedia, updateCategory);
router.delete('/categories/:id', deleteCategory);

router.get('/brands', getAdminBrands);
router.post('/brands', uploadSingleMedia, createBrand);
router.put('/brands/:id', uploadSingleMedia, updateBrand);
router.delete('/brands/:id', deleteBrand);

module.exports = router;
