const jwt = require('jsonwebtoken');

const generateToken = (id, role) =>
  jwt.sign({ id, role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });

// Sends the JWT as an httpOnly secure cookie AND in the JSON body,
// so the frontend can use either cookie-based or bearer-token auth.
const sendTokenResponse = (res, statusCode, id, role, payload) => {
  const token = generateToken(id, role);
  const cookieDays = Number(process.env.JWT_COOKIE_EXPIRES_DAYS || 7);

  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    expires: new Date(Date.now() + cookieDays * 24 * 60 * 60 * 1000),
  });

  res.status(statusCode).json({ success: true, token, ...payload });
};

module.exports = { generateToken, sendTokenResponse };
