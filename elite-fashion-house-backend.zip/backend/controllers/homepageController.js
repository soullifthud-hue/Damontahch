const Product = require('../models/Product');
const HomepageSection = require('../models/HomepageSection');
const { asyncHandler } = require('../middleware/errorHandler');

// @route GET /api/homepage
// Single call that assembles everything the homepage needs: editable content
// blocks (hero, promo banner, brand story) plus product collection rails,
// each pulled automatically from Product.flags — no manual routing by admin.
exports.getHomepageData = asyncHandler(async (req, res) => {
  const [sections, featured, newArrivals, bestSellers, trending, men, women, kids] = await Promise.all([
    HomepageSection.find({ isActive: true }).sort({ sortOrder: 1 }),
    Product.find({ status: 'published', 'flags.featured': true }).limit(12),
    Product.find({ status: 'published', 'flags.newArrival': true }).sort({ createdAt: -1 }).limit(12),
    Product.find({ status: 'published', 'flags.bestSeller': true }).sort({ soldCount: -1 }).limit(12),
    Product.find({ status: 'published', 'flags.trending': true }).limit(12),
    Product.find({ status: 'published', gender: 'Men' }).sort({ createdAt: -1 }).limit(12),
    Product.find({ status: 'published', gender: 'Women' }).sort({ createdAt: -1 }).limit(12),
    Product.find({ status: 'published', gender: 'Kids' }).sort({ createdAt: -1 }).limit(12),
  ]);

  res.status(200).json({
    success: true,
    sections,
    collections: { featured, newArrivals, bestSellers, trending, men, women, kids },
  });
});

// ---------- Admin: edit content blocks (hero, promo banner, brand story) ----------

// @route PUT /api/admin/homepage/:key
exports.upsertHomepageSection = asyncHandler(async (req, res) => {
  const { key } = req.params;
  const body = { ...req.body, key };

  if (req.file) {
    body.image = { url: req.file.path, publicId: req.file.filename };
  }

  const section = await HomepageSection.findOneAndUpdate({ key }, body, {
    new: true,
    upsert: true,
    runValidators: true,
  });

  res.status(200).json({ success: true, section });
});

// @route GET /api/admin/homepage
exports.getAdminHomepageSections = asyncHandler(async (req, res) => {
  const sections = await HomepageSection.find().sort({ sortOrder: 1 });
  res.status(200).json({ success: true, sections });
});
