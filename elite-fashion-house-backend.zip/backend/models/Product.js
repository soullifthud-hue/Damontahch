const mongoose = require('mongoose');
const slugify = require('slugify');

const imageSchema = new mongoose.Schema(
  {
    url: { type: String, required: true },
    publicId: { type: String, required: true },
    angle: { type: String, enum: ['main', 'front', 'back', 'side', 'closeup', 'gallery'], default: 'gallery' },
  },
  { _id: false }
);

const variantSchema = new mongoose.Schema(
  {
    size: String,
    color: String,
    colorHex: String,
    stock: { type: Number, default: 0, min: 0 },
    sku: String,
  },
  { _id: false }
);

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, unique: true },
    sku: { type: String, required: true, unique: true, trim: true },
    brand: { type: mongoose.Schema.Types.ObjectId, ref: 'Brand' },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
    subCategory: { type: String, trim: true },
    collection: { type: String, trim: true },
    gender: { type: String, enum: ['Men', 'Women', 'Kids', 'Unisex'], required: true },

    price: { type: Number, required: true, min: 0 },
    discountPrice: { type: Number, min: 0 },
    discountPercent: { type: Number, min: 0, max: 100 },

    stockQuantity: { type: Number, required: true, default: 0, min: 0 },
    variants: [variantSchema],
    sizes: [String],
    colors: [String],

    fabric: String,
    material: String,
    description: { type: String, required: true },
    careInstructions: String,
    shippingInfo: {
      type: String,
      default: 'Inside Dhaka: 70 BDT | Outside Dhaka: 120 BDT',
    },
    returnPolicy: { type: String, default: 'Exchange within 7 days of delivery' },

    tags: [String],
    status: { type: String, enum: ['draft', 'published', 'archived'], default: 'draft' },

    flags: {
      featured: { type: Boolean, default: false },
      bestSeller: { type: Boolean, default: false },
      newArrival: { type: Boolean, default: true },
      trending: { type: Boolean, default: false },
    },

    images: [imageSchema],

    ratingAverage: { type: Number, default: 0, min: 0, max: 5 },
    ratingCount: { type: Number, default: 0 },
    viewCount: { type: Number, default: 0 },
    soldCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

productSchema.index({ name: 'text', description: 'text', tags: 'text' });
productSchema.index({ status: 1, gender: 1, category: 1 });
productSchema.index({ 'flags.featured': 1, 'flags.bestSeller': 1, 'flags.newArrival': 1, 'flags.trending': 1 });

productSchema.pre('validate', function (next) {
  if (this.name) this.slug = slugify(`${this.name}-${this.sku || ''}`, { lower: true, strict: true });
  next();
});

productSchema.virtual('effectivePrice').get(function () {
  return this.discountPrice && this.discountPrice < this.price ? this.discountPrice : this.price;
});

productSchema.set('toJSON', { virtuals: true });
productSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('Product', productSchema);
