const express = require('express');
const router = express.Router();
const {
  getAdminCoupons, createCoupon, updateCoupon, deleteCoupon,
} = require('../controllers/couponController');
const {
  getAdminGiftCards, createGiftCard, updateGiftCard, deleteGiftCard,
} = require('../controllers/giftCardController');

router.get('/coupons', getAdminCoupons);
router.post('/coupons', createCoupon);
router.put('/coupons/:id', updateCoupon);
router.delete('/coupons/:id', deleteCoupon);

router.get('/gift-cards', getAdminGiftCards);
router.post('/gift-cards', createGiftCard);
router.put('/gift-cards/:id', updateGiftCard);
router.delete('/gift-cards/:id', deleteGiftCard);

module.exports = router;
