const express = require('express');
const router = express.Router();
const { getWishlist, addToWishlist, removeFromWishlist } = require('../controllers/wishlistController');
const { getMyOrders } = require('../controllers/orderController');
const { protectCustomer } = require('../middleware/auth');

router.use(protectCustomer);

router.get('/wishlist', getWishlist);
router.post('/wishlist/:productId', addToWishlist);
router.delete('/wishlist/:productId', removeFromWishlist);

router.get('/orders', getMyOrders);

module.exports = router;
