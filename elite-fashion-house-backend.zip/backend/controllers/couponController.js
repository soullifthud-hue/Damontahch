const Coupon = require('../models/Coupon');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');

// @route POST /api/coupons/validate  (public — used at checkout to preview a discount)
exports.validateCoupon = asyncHandler(async (req, res, next) => {
  const { code, subtotal = 0 } = req.body;
  const coupon = await Coupon.findOne({ code: (code || '').toUpperCase() });
  if (!coupon || !coupon.isValidNow()) return next(new AppError('This coupon is invalid or has expired.', 400));
  if (subtotal < coupon.minOrderAmount) {
    return next(new AppError(`Minimum order amount for this coupon is ৳${coupon.minOrderAmount}.`, 400));
  }
  res.status(200).json({ success: true, coupon: { code: coupon.code, type: coupon.type, value: coupon.value, description: coupon.description } });
});

// ---------- Admin ----------

exports.getAdminCoupons = asyncHandler(async (req, res) => {
  const coupons = await Coupon.find().sort({ createdAt: -1 });
  res.status(200).json({ success: true, coupons });
});

exports.createCoupon = asyncHandler(async (req, res) => {
  const coupon = await Coupon.create(req.body);
  res.status(201).json({ success: true, coupon });
});

exports.updateCoupon = asyncHandler(async (req, res, next) => {
  const coupon = await Coupon.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!coupon) return next(new AppError('Coupon not found.', 404));
  res.status(200).json({ success: true, coupon });
});

exports.deleteCoupon = asyncHandler(async (req, res, next) => {
  const coupon = await Coupon.findByIdAndDelete(req.params.id);
  if (!coupon) return next(new AppError('Coupon not found.', 404));
  res.status(200).json({ success: true, message: 'Coupon deleted.' });
});
