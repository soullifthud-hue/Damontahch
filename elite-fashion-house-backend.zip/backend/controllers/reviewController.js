const Review = require('../models/Review');
const Product = require('../models/Product');
const Order = require('../models/Order');
const AppError = require('../utils/AppError');
const notify = require('../utils/notify');
const { asyncHandler } = require('../middleware/errorHandler');

const recalculateProductRating = async (productId) => {
  const stats = await Review.aggregate([
    { $match: { product: productId, status: 'approved' } },
    { $group: { _id: '$product', avg: { $avg: '$rating' }, count: { $sum: 1 } } },
  ]);
  const { avg = 0, count = 0 } = stats[0] || {};
  await Product.findByIdAndUpdate(productId, { ratingAverage: avg, ratingCount: count });
};

// @route GET /api/products/:productId/reviews
exports.getProductReviews = asyncHandler(async (req, res) => {
  const { sort = 'newest' } = req.query;
  const sortMap = { newest: { createdAt: -1 }, oldest: { createdAt: 1 }, highest: { rating: -1 }, lowest: { rating: 1 }, helpful: { helpfulCount: -1 } };
  const reviews = await Review.find({ product: req.params.productId, status: 'approved' }).sort(sortMap[sort] || sortMap.newest);
  res.status(200).json({ success: true, count: reviews.length, reviews });
});

// @route POST /api/products/:productId/reviews
exports.createReview = asyncHandler(async (req, res, next) => {
  const { name, rating, title, text } = req.body;
  const product = await Product.findById(req.params.productId);
  if (!product) return next(new AppError('Product not found.', 404));

  let verifiedPurchase = false;
  if (req.customer) {
    const purchased = await Order.exists({
      customer: req.customer._id,
      'items.product': product._id,
      status: { $in: ['delivered', 'shipped', 'confirmed', 'processing'] },
    });
    verifiedPurchase = Boolean(purchased);
  }

  const photos = (req.files || []).map((f) => ({ url: f.path, publicId: f.filename }));

  const review = await Review.create({
    product: product._id,
    customer: req.customer ? req.customer._id : null,
    name: req.customer ? req.customer.name : name,
    rating,
    title,
    text,
    photos,
    verifiedPurchase,
  });

  await notify('new_review', `New review submitted for ${product.name}.`, `/admin/reviews/${review._id}`);

  res.status(201).json({ success: true, message: 'Review submitted and awaiting approval.', review });
});

// ---------- Admin moderation ----------

// @route GET /api/admin/reviews
exports.getAdminReviews = asyncHandler(async (req, res) => {
  const { status } = req.query;
  const filter = status ? { status } : {};
  const reviews = await Review.find(filter).sort({ createdAt: -1 }).populate('product', 'name slug');
  res.status(200).json({ success: true, count: reviews.length, reviews });
});

// @route PUT /api/admin/reviews/:id/status
exports.moderateReview = asyncHandler(async (req, res, next) => {
  const review = await Review.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!review) return next(new AppError('Review not found.', 404));
  await recalculateProductRating(review.product);
  res.status(200).json({ success: true, review });
});

// @route DELETE /api/admin/reviews/:id
exports.deleteReview = asyncHandler(async (req, res, next) => {
  const review = await Review.findByIdAndDelete(req.params.id);
  if (!review) return next(new AppError('Review not found.', 404));
  await recalculateProductRating(review.product);
  res.status(200).json({ success: true, message: 'Review deleted.' });
});
