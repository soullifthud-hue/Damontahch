const express = require('express');
const router = express.Router();
const { adminLogin, adminLogout, getAdminProfile } = require('../controllers/authController');
const { protectAdmin } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/rateLimiter');

// Mounted at /api/admin/auth — the frontend hides this behind an obscure,
// unlinked route (see ADMIN_ROUTE_SECRET in .env) rather than /admin/login.
router.post('/login', loginLimiter, adminLogin);
router.post('/logout', adminLogout);
router.get('/me', protectAdmin, getAdminProfile);

module.exports = router;
