const ContactMessage = require('../models/ContactMessage');
const AppError = require('../utils/AppError');
const notify = require('../utils/notify');
const { asyncHandler } = require('../middleware/errorHandler');

// @route POST /api/contact
exports.submitContactForm = asyncHandler(async (req, res, next) => {
  const { name, email, phone, subject, message } = req.body;
  if (!name || !email || !message) return next(new AppError('Name, email and message are required.', 400));

  const entry = await ContactMessage.create({ name, email, phone, subject, message });
  await notify('contact_submission', `New contact message from ${name}.`, `/admin/contact/${entry._id}`);

  res.status(201).json({ success: true, message: 'Message sent. We will get back to you soon.' });
});

// ---------- Admin ----------

exports.getContactMessages = asyncHandler(async (req, res) => {
  const { status } = req.query;
  const filter = status ? { status } : {};
  const messages = await ContactMessage.find(filter).sort({ createdAt: -1 });
  res.status(200).json({ success: true, count: messages.length, messages });
});

exports.updateContactStatus = asyncHandler(async (req, res, next) => {
  const entry = await ContactMessage.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!entry) return next(new AppError('Message not found.', 404));
  res.status(200).json({ success: true, message: entry });
});
