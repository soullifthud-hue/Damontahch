const express = require('express');
const router = express.Router();
const { getAdminOrders, updateOrderStatus } = require('../controllers/orderController');

router.get('/', getAdminOrders);
router.put('/:id/status', updateOrderStatus);

module.exports = router;
