const Subscriber = require('../models/Subscriber');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');

// @route POST /api/newsletter/subscribe
exports.subscribe = asyncHandler(async (req, res, next) => {
  const { email } = req.body;
  if (!email) return next(new AppError('Email is required.', 400));

  const existing = await Subscriber.findOne({ email: email.toLowerCase() });
  if (existing) {
    if (!existing.isActive) {
      existing.isActive = true;
      await existing.save();
    }
    return res.status(200).json({ success: true, message: 'You are already subscribed.' });
  }

  await Subscriber.create({ email });
  res.status(201).json({ success: true, message: 'Subscribed successfully.' });
});

// @route POST /api/newsletter/unsubscribe
exports.unsubscribe = asyncHandler(async (req, res) => {
  await Subscriber.findOneAndUpdate({ email: (req.body.email || '').toLowerCase() }, { isActive: false });
  res.status(200).json({ success: true, message: 'Unsubscribed.' });
});

// ---------- Admin ----------

// @route GET /api/admin/newsletter/subscribers
exports.getSubscribers = asyncHandler(async (req, res) => {
  const subscribers = await Subscriber.find({ isActive: true }).sort({ createdAt: -1 });
  res.status(200).json({ success: true, count: subscribers.length, subscribers });
});

// @route GET /api/admin/newsletter/subscribers/export  (CSV)
exports.exportSubscribers = asyncHandler(async (req, res) => {
  const subscribers = await Subscriber.find({ isActive: true }).sort({ createdAt: -1 });
  const rows = ['email,subscribedAt', ...subscribers.map((s) => `${s.email},${s.createdAt.toISOString()}`)];
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="subscribers.csv"');
  res.status(200).send(rows.join('\n'));
});
