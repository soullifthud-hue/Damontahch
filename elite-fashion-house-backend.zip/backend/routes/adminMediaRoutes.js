const express = require('express');
const router = express.Router();
const { getMedia, uploadMediaFile, renameMedia, deleteMedia } = require('../controllers/mediaController');
const { uploadSingleMedia } = require('../middleware/upload');

router.get('/', getMedia);
router.post('/', uploadSingleMedia, uploadMediaFile);
router.put('/:id', renameMedia);
router.delete('/:id', deleteMedia);

module.exports = router;
