const Customer = require('../models/Customer');
const Product = require('../models/Product');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');

// @route GET /api/customers/wishlist
exports.getWishlist = asyncHandler(async (req, res) => {
  const customer = await Customer.findById(req.customer._id).populate('wishlist');
  res.status(200).json({ success: true, count: customer.wishlist.length, wishlist: customer.wishlist });
});

// @route POST /api/customers/wishlist/:productId
exports.addToWishlist = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.productId);
  if (!product) return next(new AppError('Product not found.', 404));

  const customer = await Customer.findById(req.customer._id);
  if (!customer.wishlist.includes(product._id)) {
    customer.wishlist.push(product._id);
    await customer.save();
  }
  res.status(200).json({ success: true, count: customer.wishlist.length, message: 'Added to wishlist.' });
});

// @route DELETE /api/customers/wishlist/:productId
exports.removeFromWishlist = asyncHandler(async (req, res) => {
  const customer = await Customer.findById(req.customer._id);
  customer.wishlist = customer.wishlist.filter((id) => id.toString() !== req.params.productId);
  await customer.save();
  res.status(200).json({ success: true, count: customer.wishlist.length, message: 'Removed from wishlist.' });
});
