const Notification = require('../models/Notification');
const { asyncHandler } = require('../middleware/errorHandler');

// @route GET /api/admin/notifications
exports.getNotifications = asyncHandler(async (req, res) => {
  const notifications = await Notification.find().sort({ createdAt: -1 }).limit(100);
  const unreadCount = await Notification.countDocuments({ isRead: false });
  res.status(200).json({ success: true, unreadCount, notifications });
});

// @route PUT /api/admin/notifications/:id/read
exports.markAsRead = asyncHandler(async (req, res) => {
  await Notification.findByIdAndUpdate(req.params.id, { isRead: true });
  res.status(200).json({ success: true });
});

// @route PUT /api/admin/notifications/read-all
exports.markAllAsRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ isRead: false }, { isRead: true });
  res.status(200).json({ success: true });
});
