const GiftCard = require('../models/GiftCard');
const AppError = require('../utils/AppError');
const { asyncHandler } = require('../middleware/errorHandler');

// @route POST /api/gift-cards/check  (public — check balance before applying at checkout)
exports.checkGiftCard = asyncHandler(async (req, res, next) => {
  const { code } = req.body;
  const giftCard = await GiftCard.findOne({ code: (code || '').toUpperCase() });
  if (!giftCard || !giftCard.isActive || giftCard.expiresAt < new Date()) {
    return next(new AppError('Invalid or expired gift card.', 400));
  }
  res.status(200).json({ success: true, code: giftCard.code, balance: giftCard.balance, expiresAt: giftCard.expiresAt });
});

// ---------- Admin ----------

exports.getAdminGiftCards = asyncHandler(async (req, res) => {
  const giftCards = await GiftCard.find().sort({ createdAt: -1 });
  res.status(200).json({ success: true, giftCards });
});

exports.createGiftCard = asyncHandler(async (req, res) => {
  const giftCard = await GiftCard.create(req.body);
  res.status(201).json({ success: true, giftCard });
});

exports.updateGiftCard = asyncHandler(async (req, res, next) => {
  const giftCard = await GiftCard.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!giftCard) return next(new AppError('Gift card not found.', 404));
  res.status(200).json({ success: true, giftCard });
});

exports.deleteGiftCard = asyncHandler(async (req, res, next) => {
  const giftCard = await GiftCard.findByIdAndDelete(req.params.id);
  if (!giftCard) return next(new AppError('Gift card not found.', 404));
  res.status(200).json({ success: true, message: 'Gift card deleted.' });
});
